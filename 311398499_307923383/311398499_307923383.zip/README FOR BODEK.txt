Hi Dear Bodek! 

Welcome to our project! 

We wish to point out a few highlights: 

1. We have added a visualisation of the edge and entropy calculations - see: EdgeAndEntropy.jpg Edge.jpg Entropy.jpg
2. Original images were added for reference purposes.
3. inserted_seams_1 visually shows the algorithms incredible(!) choice of seams in a relatively complex image.

Thank you! 

Jonathan and Ido